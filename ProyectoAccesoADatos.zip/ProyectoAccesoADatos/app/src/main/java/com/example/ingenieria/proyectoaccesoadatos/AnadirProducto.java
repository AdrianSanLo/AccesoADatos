
package com.example.ingenieria.proyectoaccesoadatos;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AnadirProducto extends AppCompatActivity {

    Button volver;
    Button guardar;
    EditText codProducto;
    EditText nombre;
    EditText descripcion;
    EditText fechaAlmacenamiento;
    EditText urlImagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anadir_producto);
        getSupportActionBar().hide();

        volver = (Button) findViewById(R.id.botonVolver);
        guardar = (Button) findViewById(R.id.botonGuardar);
        codProducto = (EditText) findViewById(R.id.codigoProducto);
        nombre = (EditText) findViewById(R.id.nombreProducto);
        descripcion = (EditText) findViewById(R.id.descripcionProducto);
        fechaAlmacenamiento = (EditText) findViewById(R.id.fechaProducto);
        urlImagen = (EditText) findViewById(R.id.urlProducto);

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarProducto();
            }
        });

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AnadirProducto.this, MainActivity.class);
                finish();
            }
        });
    }

    public void guardarProducto(){

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminProductos");
        SQLiteDatabase db = admin.getWritableDatabase();

        String cod = codProducto.getText().toString();
        String nom = nombre.getText().toString();
        String des = descripcion.getText().toString();
        String fech = fechaAlmacenamiento.getText().toString();
        String url = urlImagen.getText().toString();

        String insert = "INSERT INTO productos(codProducto, nombreProducto, descripcionProducto, fechaAlmacenamientoProducto, urlImagenProducto) VALUES('"+cod+"', '"+nom+"', '"+des+"','"+fech+"','"+url+"');";

        db.execSQL(insert);
        db.close();

        codProducto.setText("");
        nombre.setText("");
        descripcion.setText("");
        fechaAlmacenamiento.setText("");
        urlImagen.setText("");

        Toast.makeText(this,"Producto guardado" , Toast.LENGTH_SHORT).show();
    }
}

