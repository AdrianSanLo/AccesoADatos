package com.example.ingenieria.proyectoaccesoadatos;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener {

    MyRecyclerViewAdapter adapterNombre, adapterDescripcion, adapterFecha, adapterURL;
    Button botonAnadir, botonRecargar;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botonAnadir = (Button) findViewById(R.id.botonAnadir);
        botonRecargar = (Button) findViewById(R.id.botonRefrescar);

        mostrarProductos();

        botonRecargar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        botonAnadir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, AnadirProducto.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onItemClick(View view, int position) {

    }

    public void mostrarProductos() {

        RecyclerView recyclerView = findViewById(R.id.rvProductos);

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminProductos");

        SQLiteDatabase db = admin.getWritableDatabase();

        ArrayList<String> inventario = new ArrayList<>();

        Cursor filas = db.rawQuery("SELECT * FROM productos", null);

        filas.moveToFirst();

        if (filas != null) {
            if (filas.moveToFirst()) {
                do {
                    String nombreProducto = filas.getString(filas.getColumnIndex("nombreProducto"));
                    inventario.add(nombreProducto);
                    String desProducto = filas.getString(filas.getColumnIndex("descripcionProducto"));
                    inventario.add(desProducto);
                    String fechProducto = filas.getString(filas.getColumnIndex("fechaAlmacenamientoProducto"));
                    inventario.add(fechProducto);
                    String urlProducto = filas.getString(filas.getColumnIndex("urlImagenProducto"));
                    inventario.add(urlProducto);

                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    adapterNombre = new MyRecyclerViewAdapter(this, inventario);
                    adapterNombre.setClickListener(this);
                    recyclerView.setAdapter(adapterNombre);

                } while (filas.moveToNext());
            }
        }
    }
}
